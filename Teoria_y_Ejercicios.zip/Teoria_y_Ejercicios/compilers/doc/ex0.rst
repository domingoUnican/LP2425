Exercise 0  - Warmup
--------------------

What is a computer?  What is computation?  What is abstraction?  These
concepts are at the core of compiler writing.  In the top-level
of the ``compilers/`` directory, you'll find a small Python program
called ``warmup.py``.  Go to that file, read the comments, and follow
the instructions contained inside.







