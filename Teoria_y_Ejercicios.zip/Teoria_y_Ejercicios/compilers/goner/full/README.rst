This directory contains a complete implementation of Gone that can
run the Mandelbrot set program.  It is not the most elegant implementation,
but it "works."
